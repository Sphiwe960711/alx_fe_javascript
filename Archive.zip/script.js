function getWeather() {
    const apiKey = '4ab194322e4475b68925ea84b6febd8b';
    const city= document.getElementById('city').value;
    if (!city) {
        alert('Please enter a city');
        return; 
    }
    const currentWeatherUrl = 'https://api.openweatherappmap.org/data/2.5/weather?q=${city}&appid=${4ab194322e4475b68925ea84b6febd8b}';
    const forecastUrl = 'https://api.openweatherappmap.org/data/2.5/weather?q=${city}&appid=${4ab194322e4475b68925ea84b6febd8b}';
}
function getWeather() {
    fetch(currentWeatherUrl)
    .then(response=> response.json())
    .then(data => {
        displayWeather(data);})
        .catch(error => {
            console.error('Error fetching current weather data:', error);
            alert('Error fetching current weather data. Please try again.');
        });    
}
function displayWeather(data) {
    const tempDivInfo = document.getElementById( 'temp-div');
    const weatherInfoDiv = document.getElementById( 'weather-info');
    const weatherIcon = document.getElementById( 'weather-icon');
    const hourlyForecastDiv = document.getElementById( 'hourly-forecast');  
}
